"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { type Vulnerability, type ScanOptions, VulnerabilityDetector } from "@/lib/vulnerability-detection"
import { type SimulationOptions, type SimulationResult, AttackSimulator } from "@/lib/attack-simulation"
import { type Alert, AlertSystem } from "@/lib/alert-system"

// Initialize the core services
const vulnerabilityDetector = new VulnerabilityDetector()
const attackSimulator = new AttackSimulator()
const alertSystem = new AlertSystem()

// Define types for our context
interface SystemComponent {
  name: string
  status: "operational" | "warning" | "offline"
}

interface Activity {
  id: string
  type: "scan" | "detection" | "mitigation" | "simulation"
  description: string
  timestamp: number
}

interface ScanHistoryItem {
  id: string
  timestamp: number
  type: string
  vulnerabilitiesFound: number
}

interface SecurityContextType {
  // State
  vulnerabilities: Vulnerability[]
  alerts: Alert[]
  activities: Activity[]
  systemStatus: SystemComponent[]
  scanHistory: ScanHistoryItem[]

  // Actions
  scanSystem: (options: ScanOptions) => Promise<any>
  runAttackSimulation: (options: SimulationOptions) => Promise<SimulationResult>
  acknowledgeAlert: (alertId: string) => void
  addScanToHistory: (scan: ScanHistoryItem) => void
  mitigateVulnerability: (vulnerabilityId: string) => void
  resolveVulnerability: (vulnerabilityId: string) => void
  updateSystemStatus: (componentName: string, status: "operational" | "warning" | "offline") => void
}

// Create the context
const SecurityContext = createContext<SecurityContextType | undefined>(undefined)

// Provider component
export function SecurityProvider({ children }: { children: ReactNode }) {
  // Initialize state with mock data
  const [vulnerabilities, setVulnerabilities] = useState<Vulnerability[]>([
    {
      id: "vuln-001",
      type: "buffer-overflow",
      severity: "critical",
      location: "Process ID: 4528",
      description: "Memory allocation exceeded in web server process",
      timestamp: Date.now() - 3600000, // 1 hour ago
      status: "new",
    },
    {
      id: "vuln-002",
      type: "sql-injection",
      severity: "high",
      location: "Database connection handler",
      description: "Unsanitized input in query parameters",
      timestamp: Date.now() - 7200000, // 2 hours ago
      status: "investigating",
    },
    {
      id: "vuln-003",
      type: "xss",
      severity: "medium",
      location: "User profile page",
      description: "Unescaped user input rendered in HTML",
      timestamp: Date.now() - 86400000, // 1 day ago
      status: "mitigated",
    },
    {
      id: "vuln-004",
      type: "cache-poisoning",
      severity: "low",
      location: "CDN cache",
      description: "Potential cache poisoning in static assets",
      timestamp: Date.now() - 172800000, // 2 days ago
      status: "resolved",
    },
  ])

  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: "alert-001",
      vulnerability: {
        id: "vuln-001",
        type: "buffer-overflow",
        severity: "critical",
        location: "Process ID: 4528",
        description: "Memory allocation exceeded in web server process",
        timestamp: Date.now() - 3600000,
        status: "new",
      },
      created: new Date(Date.now() - 3600000),
      acknowledged: false,
      mitigationSteps: [
        "Update affected software to latest version",
        "Implement address space layout randomization (ASLR)",
        "Use memory-safe programming languages or bounds checking",
        "Apply stack canaries to detect buffer overflows",
      ],
    },
    {
      id: "alert-002",
      vulnerability: {
        id: "vuln-002",
        type: "sql-injection",
        severity: "high",
        location: "Database connection handler",
        description: "Unsanitized input in query parameters",
        timestamp: Date.now() - 7200000,
        status: "investigating",
      },
      created: new Date(Date.now() - 7200000),
      acknowledged: false,
      mitigationSteps: [
        "Use parameterized queries or prepared statements",
        "Implement input validation and sanitization",
        "Apply principle of least privilege to database accounts",
        "Consider using an ORM framework",
      ],
    },
  ])

  const [activities, setActivities] = useState<Activity[]>([
    {
      id: "activity-001",
      type: "scan",
      description: "System scan completed",
      timestamp: Date.now() - 3600000, // 1 hour ago
    },
    {
      id: "activity-002",
      type: "detection",
      description: "Buffer overflow detected",
      timestamp: Date.now() - 3500000, // 58 minutes ago
    },
    {
      id: "activity-003",
      type: "detection",
      description: "SQL injection vulnerability found",
      timestamp: Date.now() - 7200000, // 2 hours ago
    },
    {
      id: "activity-004",
      type: "mitigation",
      description: "XSS vulnerability patched",
      timestamp: Date.now() - 86000000, // ~1 day ago
    },
    {
      id: "activity-005",
      type: "simulation",
      description: "Attack simulation run",
      timestamp: Date.now() - 172000000, // ~2 days ago
    },
  ])

  const [systemStatus, setSystemStatus] = useState<SystemComponent[]>([
    { name: "Detection Engine", status: "operational" },
    { name: "Attack Simulator", status: "warning" },
    { name: "Alert System", status: "operational" },
    { name: "Mitigation Service", status: "offline" },
  ])

  const [scanHistory, setScanHistory] = useState<ScanHistoryItem[]>([
    {
      id: "scan-001",
      timestamp: Date.now() - 3600000, // 1 hour ago
      type: "system",
      vulnerabilitiesFound: 2,
    },
    {
      id: "scan-002",
      timestamp: Date.now() - 86400000, // 1 day ago
      type: "network",
      vulnerabilitiesFound: 1,
    },
    {
      id: "scan-003",
      timestamp: Date.now() - 172800000, // 2 days ago
      type: "application",
      vulnerabilitiesFound: 3,
    },
  ])

  // Simulate occasional system status changes for real-time effect
  useEffect(() => {
    const statusInterval = setInterval(() => {
      // Randomly update a component status
      if (Math.random() > 0.7) {
        const components = ["Detection Engine", "Attack Simulator", "Alert System", "Mitigation Service"]
        const randomComponent = components[Math.floor(Math.random() * components.length)]
        const statuses: ("operational" | "warning" | "offline")[] = ["operational", "warning", "offline"]
        const randomStatus = statuses[Math.floor(Math.random() * statuses.length)]

        updateSystemStatus(randomComponent, randomStatus)

        // Add an activity for status change
        if (randomStatus !== "operational") {
          const newActivity: Activity = {
            id: `activity-status-${Date.now()}`,
            type: "detection",
            description: `${randomComponent} status changed to ${randomStatus}`,
            timestamp: Date.now(),
          }
          setActivities((prev) => [newActivity, ...prev])
        }
      }
    }, 30000) // Every 30 seconds

    return () => clearInterval(statusInterval)
  }, [])

  // Define actions
  const scanSystem = async (options: ScanOptions): Promise<any> => {
    // Add a new activity
    const newActivity: Activity = {
      id: `activity-${Date.now()}`,
      type: "scan",
      description: `${options.depth || "Standard"} ${
        options.scanMemory ? "memory " : ""
      }${options.scanProcesses ? "process " : ""}${options.scanFiles ? "file " : ""}${
        options.scanNetwork ? "network " : ""
      }scan initiated`,
      timestamp: Date.now(),
    }
    setActivities((prev) => [newActivity, ...prev])

    // Update system status to show scanning
    updateSystemStatus("Detection Engine", "warning")

    try {
      // Simulate scanning delay
      const scanTime = 3 + Math.random() * 2
      await new Promise((resolve) => setTimeout(resolve, scanTime * 1000))

      // Generate some random vulnerabilities based on options
      const newVulnerabilities: Vulnerability[] = []

      if (options.scanMemory || options.scanProcesses) {
        // Chance to find buffer overflow
        if (Math.random() > 0.6) {
          const severity = Math.random() > 0.7 ? "critical" : "high"
          const newVuln: Vulnerability = {
            id: `vuln-${Date.now()}-1`,
            type: "buffer-overflow",
            severity,
            location: `Process ID: ${Math.floor(Math.random() * 10000)}`,
            description: "Memory allocation exceeded in application process",
            timestamp: Date.now(),
            status: "new",
          }
          newVulnerabilities.push(newVuln)

          // Create an alert for this vulnerability
          const mitigationSteps = vulnerabilityDetector.getMitigationSteps(newVuln)
          const newAlert: Alert = {
            id: `alert-${Date.now()}-1`,
            vulnerability: newVuln,
            created: new Date(),
            acknowledged: false,
            mitigationSteps,
          }
          setAlerts((prev) => [newAlert, ...prev])

          // Add detection activity
          const detectionActivity: Activity = {
            id: `activity-${Date.now()}-1`,
            type: "detection",
            description: `${severity} buffer overflow detected in ${newVuln.location}`,
            timestamp: Date.now(),
          }
          setActivities((prev) => [detectionActivity, ...prev])
        }
      }

      if (options.scanNetwork) {
        // Chance to find SQL injection
        if (Math.random() > 0.7) {
          const severity = Math.random() > 0.5 ? "high" : "medium"
          const newVuln: Vulnerability = {
            id: `vuln-${Date.now()}-2`,
            type: "sql-injection",
            severity,
            location: "Database connection handler",
            description: "Unsanitized input in query parameters",
            timestamp: Date.now(),
            status: "new",
          }
          newVulnerabilities.push(newVuln)

          // Create an alert for this vulnerability
          const mitigationSteps = vulnerabilityDetector.getMitigationSteps(newVuln)
          const newAlert: Alert = {
            id: `alert-${Date.now()}-2`,
            vulnerability: newVuln,
            created: new Date(),
            acknowledged: false,
            mitigationSteps,
          }
          setAlerts((prev) => [newAlert, ...prev])

          // Add detection activity
          const detectionActivity: Activity = {
            id: `activity-${Date.now()}-2`,
            type: "detection",
            description: `${severity} SQL injection vulnerability found in ${newVuln.location}`,
            timestamp: Date.now(),
          }
          setActivities((prev) => [detectionActivity, ...prev])
        }
      }

      // Update vulnerabilities state
      setVulnerabilities((prev) => [...newVulnerabilities, ...prev])

      // Add scan completion activity
      const completionActivity: Activity = {
        id: `activity-${Date.now()}-complete`,
        type: "scan",
        description: `Scan completed: ${newVulnerabilities.length} vulnerabilities found`,
        timestamp: Date.now(),
      }
      setActivities((prev) => [completionActivity, ...prev])

      // Reset system status
      updateSystemStatus("Detection Engine", "operational")

      // Return scan results
      return {
        scanTime,
        vulnerabilities: newVulnerabilities,
        timestamp: Date.now(),
      }
    } catch (error) {
      // Handle errors
      console.error("Scan failed:", error)

      // Update system status to show error
      updateSystemStatus("Detection Engine", "offline")

      // Add error activity
      const errorActivity: Activity = {
        id: `activity-${Date.now()}-error`,
        type: "scan",
        description: `Scan failed: ${error instanceof Error ? error.message : "Unknown error"}`,
        timestamp: Date.now(),
      }
      setActivities((prev) => [errorActivity, ...prev])

      return {
        error: true,
        message: error instanceof Error ? error.message : "Unknown error",
        timestamp: Date.now(),
      }
    }
  }

  const runAttackSimulation = async (options: SimulationOptions): Promise<SimulationResult> => {
    // Add a new activity
    const newActivity: Activity = {
      id: `activity-${Date.now()}`,
      type: "simulation",
      description: `${options.attackVector.replace(/-/g, " ")} attack simulation initiated`,
      timestamp: Date.now(),
    }
    setActivities((prev) => [newActivity, ...prev])

    // Update system status to show simulation in progress
    updateSystemStatus("Attack Simulator", "warning")

    try {
      // Simulate the attack running
      await new Promise((resolve) => setTimeout(resolve, options.intensity * 50))

      // Generate a result based on the options
      const successful = options.intensity > 70
      const timeToDetect = Math.floor(Math.random() * 2000) + 500

      // Different detection systems based on attack vector
      let detectionSystems: string[] = []
      switch (options.attackVector) {
        case "buffer-overflow":
          detectionSystems = ["Memory Monitor", "Process Analyzer", "System Integrity Checker"]
          break
        case "sql-injection":
          detectionSystems = ["Database Firewall", "Query Analyzer", "Input Validator"]
          break
        case "dos":
          detectionSystems = ["Traffic Monitor", "Resource Manager", "Rate Limiter"]
          break
        case "xss":
          detectionSystems = ["Content Security Policy", "Input Sanitizer", "Output Encoder"]
          break
        case "cache-poisoning":
          detectionSystems = ["Cache Validator", "HTTP Header Analyzer", "Response Integrity Checker"]
          break
        default:
          detectionSystems = ["Generic Detection System"]
      }

      // Determine which systems detected the attack based on intensity
      const detectedBy =
        options.intensity > 70
          ? detectionSystems.slice(0, 1)
          : options.intensity > 40
            ? detectionSystems.slice(0, 2)
            : detectionSystems

      // Generate vulnerabilities exploited based on attack vector
      let vulnerabilitiesExploited: string[] = []
      if (successful) {
        switch (options.attackVector) {
          case "buffer-overflow":
            vulnerabilitiesExploited = ["Stack buffer overflow in process handler"]
            break
          case "sql-injection":
            vulnerabilitiesExploited = ["Unsanitized input in database query"]
            break
          case "dos":
            vulnerabilitiesExploited = ["Resource exhaustion in request handler"]
            break
          case "xss":
            vulnerabilitiesExploited = ["Unescaped user input in HTML rendering"]
            break
          case "cache-poisoning":
            vulnerabilitiesExploited = ["Improper cache validation in CDN"]
            break
          default:
            vulnerabilitiesExploited = ["Unknown vulnerability"]
        }
      }

      // Calculate mitigation effectiveness (inverse relationship with success)
      const mitigationEffectiveness = successful
        ? Math.floor(Math.random() * 40) + 10 // 10-50% if successful
        : Math.floor(Math.random() * 30) + 70 // 70-100% if unsuccessful

      // If the attack was successful and not in safe mode, create a new vulnerability
      if (successful && !options.safeMode) {
        const newVuln: Vulnerability = {
          id: `vuln-${Date.now()}`,
          type: options.attackVector,
          severity: "critical",
          location: `${options.target} environment`,
          description: `Vulnerability exploited during ${options.attackVector.replace(/-/g, " ")} simulation`,
          timestamp: Date.now(),
          status: "new",
        }
        setVulnerabilities((prev) => [newVuln, ...prev])

        // Create an alert for this vulnerability
        const mitigationSteps = vulnerabilityDetector.getMitigationSteps(newVuln)
        const newAlert: Alert = {
          id: `alert-${Date.now()}`,
          vulnerability: newVuln,
          created: new Date(),
          acknowledged: false,
          mitigationSteps,
        }
        setAlerts((prev) => [newAlert, ...prev])

        // Add detection activity
        const detectionActivity: Activity = {
          id: `activity-${Date.now()}-sim`,
          type: "detection",
          description: `${options.attackVector.replace(/-/g, " ")} vulnerability detected during simulation`,
          timestamp: Date.now(),
        }
        setActivities((prev) => [detectionActivity, ...prev])
      }

      // Add simulation completion activity
      const completionActivity: Activity = {
        id: `activity-${Date.now()}-complete`,
        type: "simulation",
        description: `${options.attackVector.replace(/-/g, " ")} simulation completed: ${successful ? "Attack successful" : "Attack blocked"}`,
        timestamp: Date.now(),
      }
      setActivities((prev) => [completionActivity, ...prev])

      // Reset system status
      updateSystemStatus("Attack Simulator", "operational")

      return {
        successful,
        detectedBy: detectedBy || [],
        timeToDetect,
        vulnerabilitiesExploited: vulnerabilitiesExploited || [],
        mitigationEffectiveness,
      }
    } catch (error) {
      // Handle errors
      console.error("Simulation failed:", error)

      // Update system status to show error
      updateSystemStatus("Attack Simulator", "offline")

      // Add error activity
      const errorActivity: Activity = {
        id: `activity-${Date.now()}-error`,
        type: "simulation",
        description: `Simulation failed: ${error instanceof Error ? error.message : "Unknown error"}`,
        timestamp: Date.now(),
      }
      setActivities((prev) => [errorActivity, ...prev])

      // Return a default result
      return {
        successful: false,
        detectedBy: ["Error Handler"],
        timeToDetect: 0,
        vulnerabilitiesExploited: [],
        mitigationEffectiveness: 0,
      }
    }
  }

  const acknowledgeAlert = (alertId: string) => {
    setAlerts((prev) => prev.map((alert) => (alert.id === alertId ? { ...alert, acknowledged: true } : alert)))

    // Add a mitigation activity
    const alert = alerts.find((a) => a.id === alertId)
    if (alert) {
      const newActivity: Activity = {
        id: `activity-${Date.now()}`,
        type: "mitigation",
        description: `${alert.vulnerability.type.replace(/-/g, " ")} vulnerability acknowledged`,
        timestamp: Date.now(),
      }
      setActivities((prev) => [newActivity, ...prev])

      // Update the vulnerability status
      setVulnerabilities((prev) =>
        prev.map((vuln) => (vuln.id === alert.vulnerability.id ? { ...vuln, status: "investigating" } : vuln)),
      )
    }
  }

  const mitigateVulnerability = (vulnerabilityId: string) => {
    // Update vulnerability status
    setVulnerabilities((prev) =>
      prev.map((vuln) => (vuln.id === vulnerabilityId ? { ...vuln, status: "mitigated" } : vuln)),
    )

    // Add a mitigation activity
    const vulnerability = vulnerabilities.find((v) => v.id === vulnerabilityId)
    if (vulnerability) {
      const newActivity: Activity = {
        id: `activity-${Date.now()}`,
        type: "mitigation",
        description: `${vulnerability.type.replace(/-/g, " ")} vulnerability mitigated`,
        timestamp: Date.now(),
      }
      setActivities((prev) => [newActivity, ...prev])
    }
  }

  const resolveVulnerability = (vulnerabilityId: string) => {
    // Update vulnerability status
    setVulnerabilities((prev) =>
      prev.map((vuln) => (vuln.id === vulnerabilityId ? { ...vuln, status: "resolved" } : vuln)),
    )

    // Add a mitigation activity
    const vulnerability = vulnerabilities.find((v) => v.id === vulnerabilityId)
    if (vulnerability) {
      const newActivity: Activity = {
        id: `activity-${Date.now()}`,
        type: "mitigation",
        description: `${vulnerability.type.replace(/-/g, " ")} vulnerability resolved`,
        timestamp: Date.now(),
      }
      setActivities((prev) => [newActivity, ...prev])
    }
  }

  const updateSystemStatus = (componentName: string, status: "operational" | "warning" | "offline") => {
    setSystemStatus((prev) =>
      prev.map((component) => (component.name === componentName ? { ...component, status } : component)),
    )
  }

  const addScanToHistory = (scan: ScanHistoryItem) => {
    setScanHistory((prev) => [scan, ...prev])
  }

  // Create the context value
  const contextValue: SecurityContextType = {
    vulnerabilities,
    alerts,
    activities,
    systemStatus,
    scanHistory,
    scanSystem,
    runAttackSimulation,
    acknowledgeAlert,
    addScanToHistory,
    mitigateVulnerability,
    resolveVulnerability,
    updateSystemStatus,
  }

  return <SecurityContext.Provider value={contextValue}>{children}</SecurityContext.Provider>
}

// Custom hook to use the context
export function useSecurity() {
  const context = useContext(SecurityContext)
  if (context === undefined) {
    throw new Error("useSecurity must be used within a SecurityProvider")
  }
  return context
}

