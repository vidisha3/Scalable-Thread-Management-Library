import { DashboardHeader } from "@/components/dashboard-header"
import { VulnerabilityScanner } from "@/components/vulnerability-scanner"
import { AttackSimulator } from "@/components/attack-simulator"
import { AlertsPanel } from "@/components/alerts-panel"
import { SystemStatus } from "@/components/system-status"
import { RecentActivities } from "@/components/recent-activities"
import { SecurityMetrics } from "@/components/security-metrics"
import { VulnerabilityReport } from "@/components/vulnerability-report"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col bg-slate-50">
      <DashboardHeader />
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-3xl font-bold mb-2">Security Vulnerability Detection Framework</h1>
        <p className="text-muted-foreground mb-6">Detect, simulate, and mitigate security vulnerabilities</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <SystemStatus />
          <SecurityMetrics />
          <RecentActivities />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <VulnerabilityReport />
          </div>
          <AlertsPanel />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <VulnerabilityScanner />
          <AttackSimulator />
        </div>
      </div>
    </main>
  )
}

