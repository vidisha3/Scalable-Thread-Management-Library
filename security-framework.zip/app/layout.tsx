import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { SecurityProvider } from "@/context/security-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Security Vulnerability Detection Framework",
  description: "A framework to detect and mitigate security vulnerabilities in operating systems",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <SecurityProvider>{children}</SecurityProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'