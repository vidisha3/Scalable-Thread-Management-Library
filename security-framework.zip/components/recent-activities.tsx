"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, AlertCircle, CheckCircle, Activity } from "lucide-react"
import { useSecurity } from "@/context/security-context"
import { useEffect, useState } from "react"

export function RecentActivities() {
  const { activities } = useSecurity()
  const [mounted, setMounted] = useState(false)

  // Prevent hydration errors
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "scan":
        return <Shield className="h-5 w-5 text-blue-500" />
      case "detection":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "mitigation":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "simulation":
        return <Activity className="h-5 w-5 text-purple-500" />
      default:
        return <Shield className="h-5 w-5 text-blue-500" />
    }
  }

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.round(diffMs / 60000)
    const diffHours = Math.round(diffMs / 3600000)
    const diffDays = Math.round(diffMs / 86400000)

    if (diffMins < 60) {
      return `${diffMins} minute${diffMins !== 1 ? "s" : ""} ago`
    } else if (diffHours < 24) {
      return `${diffHours} hour${diffHours !== 1 ? "s" : ""} ago`
    } else if (diffDays === 1) {
      return "Yesterday"
    } else {
      return date.toLocaleDateString()
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activities</CardTitle>
        <CardDescription>Latest security events</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.slice(0, 5).map((activity) => (
            <div key={activity.id} className="flex gap-3">
              <div className="mt-0.5">{getActivityIcon(activity.type)}</div>
              <div>
                <p className="text-sm font-medium">{activity.description}</p>
                <p className="text-xs text-muted-foreground">{formatTimestamp(activity.timestamp)}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

