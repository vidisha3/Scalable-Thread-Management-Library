"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, AlertCircle, CheckCircle } from "lucide-react"
import { useSecurity } from "@/context/security-context"
import { useEffect, useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreHorizontal } from "lucide-react"

export function AlertsPanel() {
  const { alerts, acknowledgeAlert, mitigateVulnerability, resolveVulnerability } = useSecurity()
  const [mounted, setMounted] = useState(false)
  const [selectedAlert, setSelectedAlert] = useState<string | null>(null)
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  // Refresh alerts periodically to simulate real-time updates
  useEffect(() => {
    const refreshInterval = setInterval(() => {
      setRefreshTrigger((prev) => prev + 1)
    }, 10000) // Every 10 seconds

    return () => clearInterval(refreshInterval)
  }, [])

  // Prevent hydration errors
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const unacknowledgedAlerts = alerts.filter((alert) => !alert.acknowledged)

  const getAlertIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
      case "high":
        return <AlertCircle className="h-5 w-5 text-orange-500 mt-0.5" />
      case "medium":
      case "low":
        return <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
      default:
        return <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
    }
  }

  const selectedAlertData = selectedAlert ? alerts.find((alert) => alert.id === selectedAlert) : null

  const handleMitigateVulnerability = (vulnerabilityId: string) => {
    mitigateVulnerability(vulnerabilityId)
    setSelectedAlert(null)
  }

  const handleResolveVulnerability = (vulnerabilityId: string) => {
    resolveVulnerability(vulnerabilityId)
    setSelectedAlert(null)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Active Alerts</CardTitle>
        <CardDescription>Security issues requiring attention</CardDescription>
      </CardHeader>
      <CardContent>
        {unacknowledgedAlerts.length > 0 ? (
          <div className="space-y-4">
            {unacknowledgedAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-3 rounded-md ${
                  alert.vulnerability.severity === "critical"
                    ? "bg-red-50 border border-red-200"
                    : alert.vulnerability.severity === "high"
                      ? "bg-orange-50 border border-orange-200"
                      : "bg-yellow-50 border border-yellow-200"
                }`}
              >
                <div className="flex items-start gap-3">
                  {getAlertIcon(alert.vulnerability.severity)}
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-sm">{alert.vulnerability.type.replace(/-/g, " ")}</h4>
                      <Badge
                        variant={alert.vulnerability.severity === "critical" ? "destructive" : "outline"}
                        className={
                          alert.vulnerability.severity === "high"
                            ? "bg-orange-100 text-orange-700 hover:bg-orange-100"
                            : alert.vulnerability.severity === "medium"
                              ? "bg-yellow-100 text-yellow-700 hover:bg-yellow-100"
                              : ""
                        }
                      >
                        {alert.vulnerability.severity}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{alert.vulnerability.location}</p>
                    <p className="text-xs mt-2">{alert.vulnerability.description}</p>

                    <div className="flex justify-between items-center mt-3">
                      <span className="text-xs text-muted-foreground">
                        {new Date(alert.vulnerability.timestamp).toLocaleTimeString()}
                      </span>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => setSelectedAlert(alert.id)}>
                          View Details
                        </Button>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => acknowledgeAlert(alert.id)}>Acknowledge</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => mitigateVulnerability(alert.vulnerability.id)}>
                              Mark as Mitigated
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => resolveVulnerability(alert.vulnerability.id)}>
                              Mark as Resolved
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
            <h3 className="text-lg font-medium">All Clear</h3>
            <p className="text-sm text-muted-foreground mt-1">No active alerts at the moment</p>
          </div>
        )}
      </CardContent>

      <Dialog open={!!selectedAlert} onOpenChange={(open) => !open && setSelectedAlert(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{selectedAlertData?.vulnerability.type.replace(/-/g, " ")}</DialogTitle>
            <DialogDescription>Alert details and mitigation steps</DialogDescription>
          </DialogHeader>

          {selectedAlertData && (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Severity</span>
                  <Badge
                    variant={selectedAlertData.vulnerability.severity === "critical" ? "destructive" : "outline"}
                    className={
                      selectedAlertData.vulnerability.severity === "high"
                        ? "bg-orange-100 text-orange-700 hover:bg-orange-100"
                        : selectedAlertData.vulnerability.severity === "medium"
                          ? "bg-yellow-100 text-yellow-700 hover:bg-yellow-100"
                          : ""
                    }
                  >
                    {selectedAlertData.vulnerability.severity}
                  </Badge>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Location</span>
                  <span className="text-sm">{selectedAlertData.vulnerability.location}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Detected</span>
                  <span className="text-sm">
                    {new Date(selectedAlertData.vulnerability.timestamp).toLocaleString()}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <span className="text-sm capitalize">{selectedAlertData.vulnerability.status}</span>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Description</h4>
                <p className="text-sm">{selectedAlertData.vulnerability.description}</p>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Mitigation Steps</h4>
                <ul className="text-sm space-y-1 list-disc pl-5">
                  {selectedAlertData.mitigationSteps.map((step, index) => (
                    <li key={index}>{step}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedAlert(null)}>
              Close
            </Button>
            <Button
              variant="default"
              onClick={() => {
                if (selectedAlert && selectedAlertData) {
                  acknowledgeAlert(selectedAlert)
                  setSelectedAlert(null)
                }
              }}
            >
              Acknowledge
            </Button>
            {selectedAlertData && selectedAlertData.vulnerability.status === "investigating" && (
              <Button
                variant="default"
                onClick={() => {
                  if (selectedAlertData) {
                    handleMitigateVulnerability(selectedAlertData.vulnerability.id)
                  }
                }}
              >
                Mark as Mitigated
              </Button>
            )}
            {selectedAlertData && selectedAlertData.vulnerability.status === "mitigated" && (
              <Button
                variant="default"
                onClick={() => {
                  if (selectedAlertData) {
                    handleResolveVulnerability(selectedAlertData.vulnerability.id)
                  }
                }}
              >
                Mark as Resolved
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}

