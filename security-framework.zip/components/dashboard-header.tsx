"use client"

import { Bell, Settings, User, Shield, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useSecurity } from "@/context/security-context"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function DashboardHeader() {
  const { alerts } = useSecurity()
  const [mounted, setMounted] = useState(false)

  // Prevent hydration errors
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const unacknowledgedAlerts = alerts.filter((alert) => !alert.acknowledged)

  return (
    <header className="border-b bg-white">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-red-600 flex items-center justify-center">
            <Shield className="h-5 w-5 text-white" />
          </div>
          <span className="font-bold text-lg">SecureGuard</span>
        </div>

        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col gap-4 mt-8">
                <Button variant="outline" className="justify-start">
                  Dashboard
                </Button>
                <Button variant="outline" className="justify-start">
                  Vulnerabilities
                </Button>
                <Button variant="outline" className="justify-start">
                  Simulations
                </Button>
                <Button variant="outline" className="justify-start">
                  Reports
                </Button>
                <Button variant="outline" className="justify-start">
                  Settings
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>

        <div className="hidden md:flex items-center gap-6">
          <nav className="flex items-center gap-4">
            <Button variant="ghost" className="font-medium">
              Dashboard
            </Button>
            <Button variant="ghost" className="font-medium">
              Vulnerabilities
            </Button>
            <Button variant="ghost" className="font-medium">
              Simulations
            </Button>
            <Button variant="ghost" className="font-medium">
              Reports
            </Button>
          </nav>

          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  {unacknowledgedAlerts.length > 0 && (
                    <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                      {unacknowledgedAlerts.length}
                    </Badge>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {unacknowledgedAlerts.length > 0 ? (
                  unacknowledgedAlerts.slice(0, 3).map((alert) => (
                    <DropdownMenuItem key={alert.id} className="flex flex-col items-start py-2">
                      <div className="flex items-center gap-2 w-full">
                        <span className="font-medium">{alert.vulnerability.type.replace(/-/g, " ")}</span>
                        <Badge variant={alert.vulnerability.severity === "critical" ? "destructive" : "outline"}>
                          {alert.vulnerability.severity}
                        </Badge>
                      </div>
                      <span className="text-xs text-muted-foreground mt-1">{alert.vulnerability.description}</span>
                    </DropdownMenuItem>
                  ))
                ) : (
                  <DropdownMenuItem disabled>No new notifications</DropdownMenuItem>
                )}
                {unacknowledgedAlerts.length > 3 && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="justify-center text-sm">
                      View all ({unacknowledgedAlerts.length})
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Profile</DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuItem>Help</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  )
}

