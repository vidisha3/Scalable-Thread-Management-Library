"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { AlertTriangle, Play, ShieldAlert, Activity, CheckCircle2, Loader2 } from "lucide-react"
import { useSecurity } from "@/context/security-context"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

export function AttackSimulator() {
  const { runAttackSimulation, systemStatus } = useSecurity()
  const [intensity, setIntensity] = useState(30)
  const [safeMode, setSafeMode] = useState(true)
  const [simulating, setSimulating] = useState(false)
  const [progress, setProgress] = useState(0)
  const [attackVector, setAttackVector] = useState("buffer-overflow")
  const [target, setTarget] = useState("test")
  const [showResults, setShowResults] = useState(false)
  const [simulationResults, setSimulationResults] = useState<any>(null)
  const [isSimulatorOperational, setIsSimulatorOperational] = useState(true)

  // Check if attack simulator is operational
  useEffect(() => {
    const simulator = systemStatus.find((component) => component.name === "Attack Simulator")
    setIsSimulatorOperational(simulator?.status === "operational" || simulator?.status === "warning")
  }, [systemStatus])

  const startSimulation = async () => {
    setSimulating(true)
    setProgress(0)
    setShowResults(false)

    // Simulate progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 95) {
          return 95 // Hold at 95% until actual completion
        }
        return prev + Math.floor(Math.random() * 5) + 1
      })
    }, 200)

    try {
      const options = {
        attackVector: attackVector as any,
        intensity,
        target,
        safeMode,
      }

      // Run the simulation
      const results = await runAttackSimulation(options)
      setSimulationResults(results)

      // Complete the progress
      clearInterval(interval)
      setProgress(100)

      // Show results
      setSimulating(false)
      setShowResults(true)
    } catch (error) {
      console.error("Simulation error:", error)
      clearInterval(interval)
      setProgress(0)
      setSimulating(false)
    }
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Attack Simulation System
            {!isSimulatorOperational && (
              <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">Simulator Offline</span>
            )}
          </CardTitle>
          <CardDescription>Test system defenses with controlled attack simulations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Attack Vector</Label>
            <Select value={attackVector} onValueChange={setAttackVector}>
              <SelectTrigger>
                <SelectValue placeholder="Select attack type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="buffer-overflow">Buffer Overflow</SelectItem>
                <SelectItem value="sql-injection">SQL Injection</SelectItem>
                <SelectItem value="dos">Denial of Service</SelectItem>
                <SelectItem value="xss">Cross-Site Scripting</SelectItem>
                <SelectItem value="cache-poisoning">Cache Poisoning</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              {attackVector === "buffer-overflow"
                ? "Attempts to write data beyond allocated memory buffers, potentially allowing code execution"
                : attackVector === "sql-injection"
                  ? "Inserts malicious SQL code into database queries through unsanitized inputs"
                  : attackVector === "dos"
                    ? "Floods system resources to make services unavailable to legitimate users"
                    : attackVector === "xss"
                      ? "Injects malicious scripts that execute in users' browsers when viewing compromised pages"
                      : "Manipulates cached data to serve malicious content or redirect users"}
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Attack Intensity</Label>
              <span className="text-sm">{intensity}%</span>
            </div>
            <Slider value={[intensity]} min={10} max={100} step={5} onValueChange={(value) => setIntensity(value[0])} />
            <p className="text-xs text-muted-foreground mt-1">
              {intensity < 30
                ? "Low intensity: Basic attack patterns that most systems can detect"
                : intensity < 70
                  ? "Medium intensity: More sophisticated attack patterns that may evade basic defenses"
                  : "High intensity: Advanced attack patterns that can potentially bypass security measures"}
            </p>
          </div>

          <div className="space-y-2">
            <Label>Target System</Label>
            <Select value={target} onValueChange={setTarget}>
              <SelectTrigger>
                <SelectValue placeholder="Select target" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="test">Test Environment</SelectItem>
                <SelectItem value="dev">Development Server</SelectItem>
                <SelectItem value="staging">Staging Environment</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="safe-mode">Safe Mode</Label>
              <p className="text-xs text-muted-foreground">Prevent actual system damage</p>
            </div>
            <Switch id="safe-mode" checked={safeMode} onCheckedChange={setSafeMode} />
          </div>

          {simulating && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>
                  {progress < 30
                    ? "Preparing attack vectors..."
                    : progress < 60
                      ? "Executing simulation..."
                      : progress < 90
                        ? "Analyzing defense responses..."
                        : "Finalizing results..."}
                </span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} />
            </div>
          )}
        </CardContent>
        <CardFooter className="flex-col space-y-4">
          {!safeMode && (
            <div className="flex items-center gap-2 text-amber-600 text-sm w-full bg-amber-50 p-2 rounded-md">
              <AlertTriangle className="h-4 w-4" />
              <span>Warning: Safe Mode is disabled. This could cause actual system damage.</span>
            </div>
          )}
          <Button className="w-full" onClick={startSimulation} disabled={!isSimulatorOperational || simulating}>
            {simulating ? (
              <>Simulating Attack...</>
            ) : !isSimulatorOperational ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Simulator Offline
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Run Simulation
              </>
            )}
          </Button>
        </CardFooter>
      </Card>

      <Dialog open={showResults} onOpenChange={setShowResults}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-purple-500" />
              Simulation Results
            </DialogTitle>
            <DialogDescription>Results of the {attackVector.replace(/-/g, " ")} attack simulation</DialogDescription>
          </DialogHeader>

          {simulationResults && (
            <div className="space-y-4">
              <div
                className={`p-4 rounded-md ${
                  simulationResults.successful
                    ? "bg-red-50 border border-red-200"
                    : "bg-green-50 border border-green-200"
                }`}
              >
                <div className="flex items-center gap-2">
                  {simulationResults.successful ? (
                    <ShieldAlert className="h-5 w-5 text-red-500" />
                  ) : (
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  )}
                  <span className="font-medium">
                    {simulationResults.successful ? "Attack Successful" : "Attack Blocked"}
                  </span>
                </div>
                <p className="text-sm mt-2">
                  {simulationResults.successful
                    ? "The attack was able to exploit vulnerabilities in the system."
                    : "The system successfully defended against the attack."}
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Detection Details</h4>
                <div className="text-sm">
                  <p>
                    Detected by:{" "}
                    {simulationResults.detectedBy && Array.isArray(simulationResults.detectedBy)
                      ? simulationResults.detectedBy.join(", ")
                      : "None"}
                  </p>
                  <p>Time to detect: {(simulationResults.timeToDetect / 1000).toFixed(2)}s</p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Vulnerabilities Exploited</h4>
                {simulationResults.vulnerabilitiesExploited &&
                Array.isArray(simulationResults.vulnerabilitiesExploited) &&
                simulationResults.vulnerabilitiesExploited.length > 0 ? (
                  <ul className="text-sm list-disc pl-5">
                    {simulationResults.vulnerabilitiesExploited.map((v, i) => (
                      <li key={i}>{v}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm">No vulnerabilities were exploited</p>
                )}
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Mitigation Effectiveness</h4>
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Effectiveness</span>
                    <span>{simulationResults.mitigationEffectiveness}%</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        simulationResults.mitigationEffectiveness < 50
                          ? "bg-red-500"
                          : simulationResults.mitigationEffectiveness < 80
                            ? "bg-yellow-500"
                            : "bg-green-500"
                      }`}
                      style={{ width: `${simulationResults.mitigationEffectiveness}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              {simulationResults.successful && (
                <div className="bg-amber-50 p-3 rounded-md border border-amber-200">
                  <p className="text-sm font-medium text-amber-800 mb-1">Recommended Actions</p>
                  <p className="text-xs text-amber-700">
                    Review and implement the suggested mitigation steps to improve system defenses.
                  </p>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResults(false)}>
              Close
            </Button>
            <Button>Generate Report</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

