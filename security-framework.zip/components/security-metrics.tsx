"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useSecurity } from "@/context/security-context"
import { useEffect, useState } from "react"

export function SecurityMetrics() {
  const { vulnerabilities, scanHistory } = useSecurity()
  const [mounted, setMounted] = useState(false)

  // Prevent hydration errors
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  // Calculate metrics
  const criticalCount = vulnerabilities.filter((v) => v.severity === "critical").length
  const highCount = vulnerabilities.filter((v) => v.severity === "high").length
  const mediumCount = vulnerabilities.filter((v) => v.severity === "medium").length
  const lowCount = vulnerabilities.filter((v) => v.severity === "low").length

  const totalVulnerabilities = vulnerabilities.length
  const mitigatedCount = vulnerabilities.filter((v) => v.status === "mitigated" || v.status === "resolved").length
  const mitigationRate = totalVulnerabilities > 0 ? Math.round((mitigatedCount / totalVulnerabilities) * 100) : 100

  const lastScanDate = scanHistory.length > 0 ? new Date(scanHistory[0].timestamp).toLocaleDateString() : "Never"

  return (
    <Card>
      <CardHeader>
        <CardTitle>Security Metrics</CardTitle>
        <CardDescription>Key vulnerability statistics</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Critical</p>
            <p className="text-2xl font-bold text-red-600">{criticalCount}</p>
          </div>

          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">High</p>
            <p className="text-2xl font-bold text-orange-500">{highCount}</p>
          </div>

          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Medium</p>
            <p className="text-2xl font-bold text-yellow-500">{mediumCount}</p>
          </div>

          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Low</p>
            <p className="text-2xl font-bold text-green-500">{lowCount}</p>
          </div>
        </div>

        <div className="mt-6 space-y-4">
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Mitigation Rate</span>
              <span className="font-medium">{mitigationRate}%</span>
            </div>
            <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
              <div className="h-full bg-green-500 rounded-full" style={{ width: `${mitigationRate}%` }}></div>
            </div>
          </div>

          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Last Scan</span>
            <span>{lastScanDate}</span>
          </div>

          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Total Vulnerabilities</span>
            <span>{totalVulnerabilities}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

