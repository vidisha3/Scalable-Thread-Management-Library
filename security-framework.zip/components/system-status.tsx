"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, AlertTriangle, XCircle } from "lucide-react"
import { useSecurity } from "@/context/security-context"
import { useEffect, useState } from "react"

export function SystemStatus() {
  const { systemStatus } = useSecurity()
  const [mounted, setMounted] = useState(false)

  // Prevent hydration errors
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "operational":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />
      case "offline":
        return <XCircle className="h-5 w-5 text-red-500" />
      default:
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "operational":
        return <span className="text-sm text-green-500 font-medium">Operational</span>
      case "warning":
        return <span className="text-sm text-yellow-500 font-medium">Warning</span>
      case "offline":
        return <span className="text-sm text-red-500 font-medium">Offline</span>
      default:
        return <span className="text-sm text-yellow-500 font-medium">Unknown</span>
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>System Status</CardTitle>
        <CardDescription>Current security status overview</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {systemStatus.map((component) => (
            <div key={component.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {getStatusIcon(component.status)}
                <span>{component.name}</span>
              </div>
              {getStatusText(component.status)}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

