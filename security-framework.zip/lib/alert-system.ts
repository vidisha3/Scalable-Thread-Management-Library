// This file contains the alert management logic

import type { Vulnerability } from "./vulnerability-detection"

export interface Alert {
  id: string
  vulnerability: Vulnerability
  created: Date
  acknowledged: boolean
  mitigationSteps: string[]
  assignedTo?: string
}

export class AlertSystem {
  private alerts: Alert[] = []

  constructor() {
    // Initialize with some mock alerts
    this.alerts = [
      {
        id: "alert-001",
        vulnerability: {
          id: "vuln-001",
          type: "buffer-overflow",
          severity: "critical",
          location: "Process ID: 4528",
          description: "Memory allocation exceeded in web server process",
          timestamp: Date.now(),
          status: "new",
        },
        created: new Date(),
        acknowledged: false,
        mitigationSteps: [
          "Update affected software to latest version",
          "Implement address space layout randomization (ASLR)",
          "Use memory-safe programming languages or bounds checking",
          "Apply stack canaries to detect buffer overflows",
        ],
      },
    ]
  }

  getActiveAlerts(): Alert[] {
    return this.alerts.filter((alert) => !alert.acknowledged)
  }

  createAlert(vulnerability: Vulnerability, mitigationSteps: string[]): Alert {
    const alert: Alert = {
      id: `alert-${Math.floor(Math.random() * 1000)}`,
      vulnerability,
      created: new Date(),
      acknowledged: false,
      mitigationSteps,
    }

    this.alerts.push(alert)
    return alert
  }

  acknowledgeAlert(alertId: string, assignedTo?: string): void {
    const alert = this.alerts.find((a) => a.id === alertId)
    if (alert) {
      alert.acknowledged = true
      alert.assignedTo = assignedTo
    }
  }

  // In a real system, this would send notifications via email, SMS, etc.
  async sendNotification(alert: Alert): Promise<boolean> {
    console.log(`[NOTIFICATION] Critical alert: ${alert.vulnerability.type} detected`)
    return true
  }

  // Additional methods for a real implementation

  getAlertById(alertId: string): Alert | undefined {
    return this.alerts.find((a) => a.id === alertId)
  }

  updateAlert(alertId: string, updates: Partial<Alert>): Alert | undefined {
    const alert = this.alerts.find((a) => a.id === alertId)
    if (alert) {
      Object.assign(alert, updates)
      return alert
    }
    return undefined
  }

  deleteAlert(alertId: string): boolean {
    const index = this.alerts.findIndex((a) => a.id === alertId)
    if (index !== -1) {
      this.alerts.splice(index, 1)
      return true
    }
    return false
  }

  getAlertsByVulnerabilityType(type: string): Alert[] {
    return this.alerts.filter((a) => a.vulnerability.type === type)
  }

  getAlertsBySeverity(severity: string): Alert[] {
    return this.alerts.filter((a) => a.vulnerability.severity === severity)
  }
}

